PROJECT DRACO LAUNCHER — LOBBY UPDATE
Version: UI prototype for Chapter 1 Season 8 / target build 8.51

What's updated:
- You no longer choose one bot difficulty for the whole match.
- The lobby can contain Noob, Medium, and Good bots together.
- Set the number of each bot type in the Lobby screen.
- Choose the game mode in the Lobby screen.

IMPORTANT:
This is a user-interface prototype only. It does not include Fortnite, game files, real AI bots, or a working game-launch integration. The Save Lobby Setup button only demonstrates the UI.

To run:
1. Install Python 3 from https://www.python.org/downloads/windows/
2. Run START_LAUNCHER.bat
