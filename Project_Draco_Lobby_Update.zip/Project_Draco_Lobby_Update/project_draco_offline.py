import tkinter as tk
from tkinter import ttk, messagebox
import webbrowser

# Project Draco UI prototype. This is not a game and does not include real bots.
BG = "#0b1220"
PANEL = "#121e30"
PANEL2 = "#192a42"
TEXT = "#f3f7ff"
MUTED = "#a9bad1"
BLUE = "#1677ff"
CYAN = "#62d5ff"
GREEN = "#4fe0a0"
GOLD = "#ffca69"

root = tk.Tk()
root.title("Project Draco | Chapter 1 Season 8")
root.geometry("1100x720")
root.minsize(900, 620)
root.configure(bg=BG)

style = ttk.Style()
style.theme_use("clam")
style.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT, arrowcolor=TEXT)
style.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", TEXT)])

def label(parent, text, size=10, color=TEXT, bold=False, **kwargs):
    return tk.Label(parent, text=text, bg=kwargs.pop("bg", PANEL), fg=color,
                    font=("Segoe UI", size, "bold" if bold else "normal"), **kwargs)

header = tk.Frame(root, bg=BG)
header.pack(fill="x", padx=24, pady=(18, 12))
label(header, "🐉  PROJECT DRACO", 24, TEXT, True, bg=BG).pack(side="left")
label(header, "CHAPTER 1 • SEASON 8     |     BUILD 8.51", 10, CYAN, True, bg=BG).pack(side="right", pady=12)
tk.Frame(root, bg=BLUE, height=2).pack(fill="x", padx=24, pady=(0, 14))

nav = tk.Frame(root, bg=BG)
nav.pack(fill="x", padx=24, pady=(0, 12))
content = tk.Frame(root, bg=BG)
content.pack(fill="both", expand=True, padx=24, pady=(0, 14))

def clear_content():
    for child in content.winfo_children():
        child.destroy()

def panel(parent, padx=18, pady=16):
    f = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground="#263b58")
    f.pack(fill="both", expand=True, padx=6, pady=6)
    return f

def show_home():
    clear_content()
    wrap = tk.Frame(content, bg=BG)
    wrap.pack(fill="both", expand=True)
    left = tk.Frame(wrap, bg=PANEL, highlightthickness=1, highlightbackground="#263b58")
    left.pack(side="left", fill="both", expand=True, padx=(0, 8))
    right = tk.Frame(wrap, bg=PANEL, highlightthickness=1, highlightbackground="#263b58", width=290)
    right.pack(side="right", fill="y", padx=(8, 0))
    right.pack_propagate(False)
    label(left, "YOUR ISLAND. YOUR MATCH.", 11, CYAN, True).pack(anchor="w", padx=24, pady=(24, 8))
    label(left, "OFFLINE OG PROJECT", 26, TEXT, True).pack(anchor="w", padx=24)
    label(left, "Prepare your lobby, choose a mode, and mix bot difficulties.", 11, MUTED,
          wraplength=520, justify="left").pack(anchor="w", padx=24, pady=(10, 22))
    strip = tk.Frame(left, bg=PANEL2)
    strip.pack(fill="x", padx=24, pady=(0, 18))
    label(strip, "BOT LOBBY", 10, CYAN, True, bg=PANEL2).pack(anchor="w", padx=14, pady=(12, 4))
    label(strip, "Noob Bots  •  Medium Bots  •  Good Bots", 12, TEXT, True, bg=PANEL2).pack(anchor="w", padx=14, pady=(0, 12))
    tk.Button(left, text="OPEN LOBBY  →", command=show_lobby, bg=BLUE, fg="white",
              activebackground="#3289ff", activeforeground="white", relief="flat",
              font=("Segoe UI", 12, "bold"), padx=18, pady=13, cursor="hand2").pack(fill="x", padx=24, pady=(4, 12))
    label(left, "This is a launcher UI demo. Game files and real AI bots are not included.", 9, GOLD,
          wraplength=520, justify="left").pack(anchor="w", padx=24, pady=(8, 20))
    label(right, "PROJECT STATUS", 12, TEXT, True).pack(anchor="w", padx=18, pady=(20, 12))
    for title, value in [("Game files", "Not installed"), ("Real bots", "Not available"), ("Mode", "Choose in Lobby"), ("Build", "8.51")]:
        row = tk.Frame(right, bg=PANEL)
        row.pack(fill="x", padx=18, pady=7)
        label(row, title, 10, MUTED).pack(side="left")
        label(row, value, 10, TEXT, True).pack(side="right")
    tk.Button(right, text="Source repository", command=lambda: webbrowser.open("https://github.com/Volcano-MP/Volcano-8.51"),
              bg=PANEL2, fg=CYAN, activebackground=PANEL2, activeforeground=CYAN,
              relief="flat", pady=10, cursor="hand2").pack(fill="x", padx=18, pady=(24, 10))

def show_lobby():
    clear_content()
    label(content, "MATCH LOBBY", 23, TEXT, True, bg=BG).pack(anchor="w", padx=6, pady=(2, 4))
    label(content, "All three bot difficulties can be present in the same lobby.", 11, MUTED, bg=BG).pack(anchor="w", padx=6, pady=(0, 14))
    body = tk.Frame(content, bg=BG)
    body.pack(fill="both", expand=True)
    bots = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground="#263b58")
    bots.pack(side="left", fill="both", expand=True, padx=(0, 8))
    settings = tk.Frame(body, bg=PANEL, highlightthickness=1, highlightbackground="#263b58")
    settings.pack(side="right", fill="both", expand=True, padx=(8, 0))
    label(bots, "LOBBY BOT MIX", 13, CYAN, True).pack(anchor="w", padx=20, pady=(18, 5))
    label(bots, "Set how many of each type join the lobby:", 10, MUTED).pack(anchor="w", padx=20, pady=(0, 14))
    bot_vars = {}
    for name, desc, default in [
        ("Noob Bots", "Beginner difficulty", 6),
        ("Medium Bots", "Balanced difficulty", 6),
        ("Good Bots", "Advanced difficulty", 4),
    ]:
        card = tk.Frame(bots, bg=PANEL2)
        card.pack(fill="x", padx=18, pady=6)
        top = tk.Frame(card, bg=PANEL2)
        top.pack(fill="x", padx=12, pady=(10, 3))
        label(top, name, 12, TEXT, True, bg=PANEL2).pack(side="left")
        var = tk.IntVar(value=default)
        bot_vars[name] = var
        spin = tk.Spinbox(top, from_=0, to=50, width=5, textvariable=var, bg=BG, fg=TEXT,
                          buttonbackground=PANEL2, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        spin.pack(side="right")
        label(card, desc, 9, MUTED, bg=PANEL2).pack(anchor="w", padx=12, pady=(0, 10))
    label(settings, "CHOOSE GAME MODE", 13, CYAN, True).pack(anchor="w", padx=20, pady=(18, 8))
    label(settings, "Pick your mode here in the lobby:", 10, MUTED).pack(anchor="w", padx=20, pady=(0, 12))
    mode = tk.StringVar(value="Battle Royale (Solo)")
    combo = ttk.Combobox(settings, textvariable=mode, state="readonly",
                         values=["Battle Royale (Solo)", "Battle Royale (Duos)", "Battle Royale (Squads)", "Practice Range"], font=("Segoe UI", 11))
    combo.pack(fill="x", padx=20, pady=(0, 18), ipady=7)
    label(settings, "MATCH SUMMARY", 11, TEXT, True).pack(anchor="w", padx=20, pady=(8, 8))
    summary = label(settings, "", 10, MUTED, justify="left", anchor="w", bg=PANEL)
    summary.pack(fill="x", padx=20, pady=(0, 14))
    def update_summary(*_):
        total = sum(max(0, v.get()) for v in bot_vars.values())
        summary.config(text=f"Mode: {mode.get()}\\nNoob: {bot_vars['Noob Bots'].get()}   Medium: {bot_vars['Medium Bots'].get()}\\nGood: {bot_vars['Good Bots'].get()}\\nTotal bots: {total}")
    for v in bot_vars.values():
        v.trace_add("write", update_summary)
    mode.trace_add("write", update_summary)
    update_summary()
    buttons = tk.Frame(settings, bg=PANEL)
    buttons.pack(fill="x", padx=20, pady=(10, 18))
    def prepare():
        total = sum(max(0, v.get()) for v in bot_vars.values())
        if total == 0:
            messagebox.showwarning("Project Draco", "Add at least one bot to the lobby.")
            return
        messagebox.showinfo("Lobby saved", f"Lobby setup saved in this demo.\\nMode: {mode.get()}\\nBots: {total}\\n\\nThis does not launch a real game yet.")
    tk.Button(buttons, text="SAVE LOBBY SETUP", command=prepare, bg=BLUE, fg="white",
              activebackground="#3289ff", activeforeground="white", relief="flat",
              font=("Segoe UI", 10, "bold"), padx=12, pady=12, cursor="hand2").pack(fill="x")
    tk.Button(buttons, text="← BACK HOME", command=show_home, bg=PANEL2, fg=TEXT,
              activebackground=PANEL2, activeforeground=TEXT, relief="flat",
              font=("Segoe UI", 10, "bold"), padx=12, pady=10, cursor="hand2").pack(fill="x", pady=(8, 0))
    label(settings, "Prototype only: lobby settings are a UI demo; real bot gameplay is not included.", 9, GOLD,
          wraplength=370, justify="left").pack(anchor="w", padx=20, pady=(0, 16))

tk.Button(nav, text="HOME", command=show_home, bg=PANEL2, fg=TEXT, activebackground=PANEL2,
          activeforeground=TEXT, relief="flat", padx=16, pady=8, cursor="hand2").pack(side="left", padx=(0, 8))
tk.Button(nav, text="LOBBY", command=show_lobby, bg=BLUE, fg="white", activebackground="#3289ff",
          activeforeground="white", relief="flat", padx=16, pady=8, cursor="hand2").pack(side="left")
label(nav, "UI PROTOTYPE • NOT A PLAYABLE GAME", 9, GOLD, True, bg=BG).pack(side="right", pady=8)

footer = tk.Frame(root, bg=BG)
footer.pack(fill="x", padx=24, pady=(0, 14))
tk.Frame(footer, bg="#263b58", height=1).pack(fill="x", pady=(0, 8))
label(footer, "PROJECT DRACO  |  OFFLINE LOBBY CONCEPT", 9, MUTED, bg=BG).pack(side="left")
show_home()
root.mainloop()
