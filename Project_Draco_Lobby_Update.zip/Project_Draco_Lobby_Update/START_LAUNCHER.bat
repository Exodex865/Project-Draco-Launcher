@echo off
cd /d "%~dp0"
python project_draco_offline.py
if errorlevel 1 pause
