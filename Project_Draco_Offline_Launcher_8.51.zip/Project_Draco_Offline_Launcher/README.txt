PROJECT DRACO — OFFLINE LAUNCHER UI PROTOTYPE
================================================

This version adds:
- Fortnite-inspired dark launcher layout
- Target build display: Chapter 1 Season 8 / 8.51
- Noob, Medium, and Good bot difficulty choices
- Offline-first and future-online status panels
- A demo loading bar

START
1. Extract this ZIP to a folder.
2. Double-click START_LAUNCHER.bat.
3. If Python is missing, install Python 3 from https://www.python.org/

IMPORTANT LIMITATIONS
This is still a UI prototype, not a working Fortnite game launcher.
The loading bar is a demo and does not download or start the game.
The bot choices are UI selections only; they do not create real bots.
Real offline matches require a compatible game build plus game-side AI/bot
support and a legitimate way to launch that build. The supplied GitHub repo
is linked in the launcher, but this package does not automatically install it.

Target source repository:
https://github.com/Volcano-MP/Volcano-8.51
