import tkinter as tk
from tkinter import messagebox
import webbrowser
import threading
import time

# Project Draco — Offline launcher prototype
# UI prototype only: this does NOT contain Fortnite, a game engine, or AI bots.
# "Prepare Offline Mode" demonstrates the launcher loading flow. It does not
# start a game. Real gameplay requires a compatible game build and game-side
# bot implementation / authorized integration.

BG = "#0d121c"
PANEL = "#171f2d"
PANEL2 = "#202c3d"
TEXT = "#f3f6fc"
MUTED = "#a8b5c8"
BLUE = "#168fe5"
CYAN = "#76d7ff"
ORANGE = "#ffb74d"
GREEN = "#5fe0a0"

root = tk.Tk()
root.title("Project Draco | Offline")
root.geometry("1120x700")
root.minsize(940, 600)
root.configure(bg=BG)

def open_repo():
    webbrowser.open("https://github.com/Volcano-MP/Volcano-8.51")

header = tk.Frame(root, bg=BG)
header.pack(fill="x", padx=28, pady=(20, 12))
left = tk.Frame(header, bg=BG)
left.pack(side="left")
tk.Label(left, text="DRACO", bg=BG, fg=TEXT,
         font=("Segoe UI", 25, "bold")).pack(anchor="w")
tk.Label(left, text="OFFLINE OG PROJECT", bg=BG, fg=CYAN,
         font=("Segoe UI", 9, "bold")).pack(anchor="w")

right = tk.Frame(header, bg=BG)
right.pack(side="right")
tk.Label(right, text="CHAPTER 1  •  SEASON 8", bg=BG, fg=TEXT,
         font=("Segoe UI", 11, "bold")).pack(anchor="e", pady=(9, 3))
tk.Label(right, text="TARGET BUILD 8.51", bg=BG, fg=ORANGE,
         font=("Segoe UI", 9, "bold")).pack(anchor="e")

tk.Frame(root, bg=BLUE, height=2).pack(fill="x", padx=28, pady=(0, 18))

main = tk.Frame(root, bg=BG)
main.pack(fill="both", expand=True, padx=28, pady=(0, 14))
main.columnconfigure(0, weight=3)
main.columnconfigure(1, weight=2)
main.rowconfigure(0, weight=1)

hero = tk.Frame(main, bg=PANEL, highlightthickness=1, highlightbackground="#2b3b51")
hero.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
inner = tk.Frame(hero, bg=PANEL)
inner.pack(fill="both", expand=True, padx=28, pady=26)

tk.Label(inner, text="YOUR ISLAND. YOUR MATCH.", bg=PANEL, fg=CYAN,
         font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 9))
tk.Label(inner, text="OFFLINE BATTLE ROYALE", bg=PANEL, fg=TEXT,
         font=("Segoe UI", 23, "bold")).pack(anchor="w")
tk.Label(inner,
         text="Play against AI bots offline. Choose a difficulty and prepare your match.",
         bg=PANEL, fg=MUTED, font=("Segoe UI", 10),
         wraplength=540, justify="left").pack(anchor="w", pady=(8, 20))

version = tk.Frame(inner, bg=PANEL2)
version.pack(fill="x", pady=(0, 18))
tk.Label(version, text="SELECTED TARGET", bg=PANEL2, fg=MUTED,
         font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=15, pady=(11, 3))
tk.Label(version, text="FORTNITE 8.51  •  CHAPTER 1 SEASON 8",
         bg=PANEL2, fg=TEXT, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=15, pady=(0, 11))

tk.Label(inner, text="BOT DIFFICULTY", bg=PANEL, fg=TEXT,
         font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 9))

difficulty = tk.StringVar(value="Noob Bots")
choices = tk.Frame(inner, bg=PANEL)
choices.pack(fill="x", pady=(0, 15))

bot_options = [
    ("Noob Bots", "Beginner"),
    ("Medium Bots", "Balanced"),
    ("Good Bots", "Challenging"),
]
for title, subtitle in bot_options:
    card = tk.Frame(choices, bg=PANEL2, highlightthickness=1, highlightbackground="#33455d")
    card.pack(side="left", fill="both", expand=True, padx=(0, 8))
    rb = tk.Radiobutton(card, text=title, variable=difficulty, value=title,
                        bg=PANEL2, fg=TEXT, selectcolor="#122b43",
                        activebackground=PANEL2, activeforeground=TEXT,
                        font=("Segoe UI", 9, "bold"), cursor="hand2")
    rb.pack(anchor="w", padx=8, pady=(10, 1))
    tk.Label(card, text=subtitle, bg=PANEL2, fg=MUTED,
             font=("Segoe UI", 8)).pack(anchor="w", padx=10, pady=(0, 10))

status_var = tk.StringVar(value="READY • Offline mode selected")
tk.Label(inner, textvariable=status_var, bg=PANEL, fg=GREEN,
         font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 8))

progress_outer = tk.Frame(inner, bg="#303b4c", height=10)
progress_outer.pack(fill="x", pady=(0, 15))
progress_outer.pack_propagate(False)
progress_fill = tk.Frame(progress_outer, bg=BLUE, width=0)
progress_fill.pack(side="left", fill="y")

buttons = tk.Frame(inner, bg=PANEL)
buttons.pack(anchor="w")

def show_not_playable():
    messagebox.showinfo(
        "Game integration required",
        "The launcher UI is ready, but it cannot start Fortnite or create real AI bots yet. "
        "This prototype does not include game files or bot AI. A compatible game build and "
        "game-side bot implementation are required before Play can work."
    )

def prepare():
    # Demonstration-only progress animation; no game is downloaded or started.
    start_btn.config(state="disabled")
    status_var.set("DEMO LOADING • Checking launcher setup...")
    progress_fill.config(width=0)
    total_width = max(progress_outer.winfo_width(), 1)

    def worker():
        messages = [
            "DEMO LOADING • Checking launcher setup...",
            "DEMO LOADING • Selected difficulty: " + difficulty.get(),
            "DEMO LOADING • Game integration is not configured.",
        ]
        for i in range(1, 101):
            time.sleep(0.018)
            width = int(total_width * i / 100)
            root.after(0, lambda w=width: progress_fill.config(width=w))
            if i == 25:
                root.after(0, lambda: status_var.set(messages[1]))
            if i == 70:
                root.after(0, lambda: status_var.set(messages[2]))
        def finish():
            status_var.set("SETUP PREVIEW COMPLETE • Game is not installed/configured")
            start_btn.config(state="normal")
            messagebox.showinfo(
                "Preview finished",
                "The loading animation is only a launcher preview. No game was downloaded, "
                "and no match or bots were started yet."
            )
        root.after(0, finish)

    threading.Thread(target=worker, daemon=True).start()

start_btn = tk.Button(buttons, text="PLAY OFFLINE  •  NOT READY", command=show_not_playable,
                      bg=BLUE, fg="white", activebackground="#1177bf",
                      activeforeground="white", relief="flat", bd=0,
                      font=("Segoe UI", 9, "bold"), padx=16, pady=11, cursor="hand2")
start_btn.pack(side="left", padx=(0, 9))
tk.Button(buttons, text="TEST LOADING UI", command=prepare,
          bg=PANEL2, fg=TEXT, activebackground="#2d3b50",
          activeforeground=TEXT, relief="flat", bd=0,
          font=("Segoe UI", 9, "bold"), padx=15, pady=11,
          cursor="hand2").pack(side="left")

side = tk.Frame(main, bg=BG)
side.grid(row=0, column=1, sticky="nsew")

def info_card(title, body, body_color=TEXT):
    card = tk.Frame(side, bg=PANEL, highlightthickness=1, highlightbackground="#2b3b51")
    card.pack(fill="x", pady=(0, 12))
    tk.Label(card, text=title, bg=PANEL, fg=CYAN,
             font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=17, pady=(14, 6))
    tk.Label(card, text=body, bg=PANEL, fg=body_color,
             font=("Segoe UI", 9), justify="left", wraplength=285).pack(anchor="w", padx=17, pady=(0, 14))
    return card

info_card("MODE", "OFFLINE FIRST\\nNo multiplayer server needed for the launcher interface.", GREEN)
info_card("BOT PRESETS", "NOOB  •  beginner\\nMEDIUM  •  balanced\\nGOOD  •  challenging")
info_card("ONLINE", "Planned for a later update when hosting is available.", ORANGE)
info_card("IMPORTANT", "This is a UI prototype. Real matches and bots require compatible game-side support.", MUTED)

repo_btn = tk.Button(side, text="OPEN 8.51 SOURCE REPOSITORY", command=open_repo,
                     bg=PANEL2, fg=TEXT, activebackground="#2d3b50",
                     activeforeground=TEXT, relief="flat", bd=0,
                     font=("Segoe UI", 8, "bold"), padx=12, pady=11, cursor="hand2")
repo_btn.pack(fill="x")

footer = tk.Frame(root, bg=BG)
footer.pack(fill="x", padx=28, pady=(0, 15))
tk.Label(footer, text="PROJECT DRACO  •  UNOFFICIAL FAN PROJECT",
         bg=BG, fg="#77879e", font=("Segoe UI", 8, "bold")).pack(side="left")
tk.Label(footer, text="NOT AFFILIATED WITH EPIC GAMES",
         bg=BG, fg="#77879e", font=("Segoe UI", 8)).pack(side="right")

root.mainloop()
