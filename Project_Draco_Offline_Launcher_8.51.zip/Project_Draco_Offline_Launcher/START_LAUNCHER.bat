@echo off
cd /d "%~dp0"
py -3 project_draco_offline.py
if errorlevel 1 (
  echo.
  echo Python could not start the launcher.
  echo Install Python 3 from https://www.python.org/ and try again.
  pause
)
